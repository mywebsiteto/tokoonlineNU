<?php 
// isi nama host, username mysql, dan password mysql anda
$conn = mysqli_connect("localhost","root","","tokonlinenu");

if(!$conn){
	echo "gagal konek database menn";
} else {
	
};

?>