<?php 
// isi nama host, username mysql, dan password mysql anda
$conn = mysqli_connect("localhost","root","root","tokoonlineNU");

if(!$conn){
	echo "gagal konek database menn";
} else {
	
};

?>